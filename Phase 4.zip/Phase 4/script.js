const mcqs = [
  {
    question: "DNA এর পূর্ণরূপ কী?",
    options: ["Deoxyribonucleic acid", "Dicarboxylic acid", "Dioxygen acid", "None"],
    answer: 0
  },
  {
    question: "RNA কোন ধরণের নিউক্লিক অ্যাসিড?",
    options: ["Double-stranded", "Single-stranded", "Triple-stranded", "None"],
    answer: 1
  },
  {
    question: "Translation কোথায় হয়?",
    options: ["Nucleus", "Cytoplasm", "Golgi", "Mitochondria"],
    answer: 1
  },
  {
    question: "Codon কয়টি base নিয়ে গঠিত?",
    options: ["2", "3", "4", "5"],
    answer: 1
  },
  {
    question: "mRNA কে পড়ে কে প্রোটিন তৈরি করে?",
    options: ["rRNA", "tRNA", "ribosome", "DNA"],
    answer: 2
  }
];

let timeLeft = 60;
let timer;
let selectedAnswers = [];

function startExam() {
  const count = parseInt(document.getElementById("mcq-count").value);
  const questions = mcqs.slice(0, count);

  const form = document.getElementById("exam-form");
  form.innerHTML = "";

  questions.forEach((q, i) => {
    const div = document.createElement("div");
    div.innerHTML = `<p><b>${i + 1}. ${q.question}</b></p>`;
    q.options.forEach((opt, j) => {
      div.innerHTML += `
        <label>
          <input type="radio" name="q${i}" value="${j}"> ${opt}
        </label><br/>
      `;
    });
    form.appendChild(div);
  });

  selectedAnswers = questions.map(q => q.answer);
  document.getElementById("exam-setup").style.display = "none";
  document.getElementById("exam-section").style.display = "block";

  timeLeft = count * 20;
  updateTimer();
  timer = setInterval(updateTimer, 1000);
}

function updateTimer() {
  const display = document.getElementById("time");
  const min = Math.floor(timeLeft / 60);
  const sec = timeLeft % 60;
  display.textContent = `${min}:${sec < 10 ? "0" : ""}${sec}`;
  if (timeLeft <= 0) {
    clearInterval(timer);
    submitExam();
  }
  timeLeft--;
}

function submitExam() {
  clearInterval(timer);
  let correct = 0;
  const form = document.getElementById("exam-form");
  selectedAnswers.forEach((ans, i) => {
    const selected = form.querySelector(`input[name="q${i}"]:checked`);
    if (selected && parseInt(selected.value) === ans) {
      correct++;
    }
  });
  const wrong = selectedAnswers.length - correct;
  document.getElementById("correct-count").textContent = correct;
  document.getElementById("wrong-count").textContent = wrong;

  document.getElementById("exam-section").style.display = "none";
  document.getElementById("result-section").style.display = "block";
}